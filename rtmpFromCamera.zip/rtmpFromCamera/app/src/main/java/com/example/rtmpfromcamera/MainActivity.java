package com.example.rtmpfromcamera;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.pedro.rtplibrary.rtmp.RtmpCamera1;
import net.ossrs.rtmp.ConnectCheckerRtmp;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import cn.nodemedia.NodePlayer;
import cn.nodemedia.NodePlayerDelegate;
import cn.nodemedia.NodePlayerView;

public class MainActivity extends AppCompatActivity
        implements ConnectCheckerRtmp, View.OnClickListener, SurfaceHolder.Callback, NodePlayerDelegate {
    private final String[] PERMISSIONS = {
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA,//音频和相机权限申请
            Manifest.permission.WRITE_EXTERNAL_STORAGE //存储空间权限申请
    };
    // 视频信息用到的变量
    private RtmpCamera1 rtmpCamera1;
    private Button btnConnect;
    private Button pushBut;
    private Button pullBut;
    private Button btnDisconnect;
    private EditText urlpush;
    private NodePlayer np;
    // 非视频信息用到的变量
    private Socket socket;
    private String temp = "";
    OutputStream outputStream;
    private LocationManager lm;//定位变量
    private StringBuilder loca_data;
    long timeGetTime =new Date().getTime();
    private Timer timer = new Timer(true);
    private ExecutorService mThreadPool;// 为了方便展示,此处直接采用线程池进行线程管理,而没有一个个开线程

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (!hasPermissions(this, PERMISSIONS)) {
            ActivityCompat.requestPermissions(this, PERMISSIONS, 1);
        }

        // 初始化变量
        init();
        //推流
        rtmpCamera1 = new RtmpCamera1(this, this);
        rtmpCamera1.setReTries(10);//设置重连次数
        // 拉流
        np = new NodePlayer(this);
        NodePlayerView npv = findViewById(R.id.surfaceView_bottom);
        npv.setRenderType(NodePlayerView.RenderType.SURFACEVIEW);
        npv.setUIViewContentMode(NodePlayerView.UIViewContentMode.ScaleAspectFit);
        np.setPlayerView(npv);
        np.setNodePlayerDelegate(this);
        np.setHWEnable(true);

        // 初始化线程池
        mThreadPool = Executors.newCachedThreadPool();
        //初始化位置变量
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        //判断GPS是否可用
        if (!isGpsAble(lm)) {
            Toast.makeText(MainActivity.this, "请打开GPS", Toast.LENGTH_SHORT).show();
            openGPS2();
        }
        //判断定位权限是否开启
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {//未开启定位权限
            //开启定位权限,200是标识码
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 200);
        } else {
            startLocation();
            Toast.makeText(MainActivity.this, "已开启定位权限", Toast.LENGTH_LONG).show();
        }

    }
    private void init(){
        btnConnect =  findViewById(R.id.connect);
        pushBut =  findViewById(R.id.b_start_stop);
        pullBut = findViewById(R.id.start_pull);
        urlpush = findViewById(R.id.url_push);
        btnDisconnect =  findViewById(R.id.disconnect);
        mThreadPool = Executors.newCachedThreadPool();
        btnConnect.setOnClickListener(this);
        pushBut.setOnClickListener(this);
        pullBut.setOnClickListener(this);
        btnDisconnect.setOnClickListener(this);
    }
    private boolean hasPermissions(Context context, String... permissions) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission)
                        != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
    //定位动态权限申请
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case 200://刚才的识别码
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED){//用户同意权限,执行我们的操作
                    startLocation();//开始定位
                }else{//用户拒绝之后,当然我们也可以弹出一个窗口,直接跳转到系统设置页面
                    Toast.makeText(MainActivity.this,"未开启定位权限,请手动到设置去开启权限",Toast.LENGTH_LONG).show();
                }
                break;
            default:break;
        }
    }
    //开始定位
    @SuppressLint("MissingPermission")
    private  void startLocation(){

        //从GPS获取最近的定位信息
        Location lc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        updateShow(lc);
        loca_data = updateShow(lc);
        //设置间隔100毫秒获得一次GPS定位信息
        lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 100, 3, new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                // 当GPS定位信息发生改变时，更新定位
                updateShow(location);
                loca_data = updateShow(location);
            }

            @Override
            public void onStatusChanged(String provider, int status, Bundle extras) {
            }

            @Override
            public void onProviderEnabled(String provider) {
                // 当GPS LocationProvider可用时，更新定位
                updateShow(lm.getLastKnownLocation(provider));
                loca_data = updateShow(lm.getLastKnownLocation(provider));
            }

            @Override
            public void onProviderDisabled(String provider) {
                updateShow(null);
            }
        });
    }
    //定义一个更新显示的方法
    private StringBuilder updateShow(Location location) {
        if (location != null) {
            StringBuilder sb1 = new StringBuilder();
            int id = 111;
            sb1.append("{'id':'"+ id + "',");
            sb1.append("'accuracy':'"+ location.getAccuracy() + "',");
            sb1.append("'speed':'"+ location.getSpeed()+ "',");
            sb1.append("'direction':'"+ location.getBearing() + "',");
            sb1.append("'wgs84':["+ location.getLongitude() + "," + location.getLatitude() + "],");
            sb1.append("'altitude':'"+ location.getAltitude() + "',");
            sb1.append("'timestamp':'"+ timeGetTime + "'}");
            return sb1;
        } else {
            return null;
        }

    }

    //判断GPS是否可用
    private boolean isGpsAble(LocationManager lm) {
        return lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER) ? true : false;
    }

    //打开设置页面让用户自己设置
    private void openGPS2() {
        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
        startActivityForResult(intent, 0);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            //建立非视频连接
            case R.id.connect:
                    mThreadPool.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                // 创建Socket对象 & 指定服务端的IP 及 端口号
                                temp = urlpush.getText().toString().replaceAll("rtmp://|:1935/live/test", "");
                                socket = new Socket(temp, 8989);
                                // 判断客户端和服务器是否连接成功
                                System.out.println(socket.isConnected());
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    });
                break;
                //推流按钮
            case R.id.b_start_stop:
                if (!rtmpCamera1.isStreaming()) {
                    if (rtmpCamera1.isRecording()
                            //这里的rotation为相机角度，设置90会正常，如果为0是头朝左的
                            || rtmpCamera1.prepareVideo(640, 480, 30, 1200 * 1024, false, 90) &&  rtmpCamera1.prepareAudio()) {
                        pushBut.setText(R.string.stop_button);
                        rtmpCamera1.startStream(urlpush.getText().toString());
                    } else {
                        Toast.makeText(this, "Error preparing stream, This device cant do it",
                                Toast.LENGTH_SHORT).show();
                    }
                } else {
                    pushBut.setText(R.string.start_button);
                    rtmpCamera1.stopStream();
                }
                // 利用线程池直接开启一个线程 & 执行该线程
                mThreadPool.execute(new Runnable() {
                    @Override
                    public void run() {
                        /**用定时器间隔发送*/
                        //定时执行任务
                        TimerTask task = new TimerTask() {
                            StringBuilder line;
                            @Override
                            public void run() {
                                try {
                                    outputStream = socket.getOutputStream();
                                    line = loca_data;
                                    outputStream.write((line + "\n").getBytes("utf-8"));
                                    //这里将缓冲区的数据冲入
                                    outputStream.flush();
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }
                        };
                        timer.schedule(task, 1000, 50);
                    }
                });
                break;
                //拉流按钮
            case R.id.start_pull:
                if(!np.isPlaying()){
                    np.setInputUrl(urlpush.getText().toString());
                    np.start();
                    pullBut.setText(getString(R.string.stop_player));
                }else {
                    np.stop();
                    pullBut.setText(getString(R.string.start_player));
                }
                break;
            case R.id.disconnect:
                // 断开 客户端发送到服务器 的连接，即关闭输出流对象OutputStream
                try {
                    outputStream.close();
                // 最终关闭整个Socket连接
                socket.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                // 判断客户端和服务器是否已经断开连接
                System.out.println(socket.isConnected());
                break;
            default:
                break;
        }
    }
    @Override
    public void onConnectionSuccessRtmp() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Connection success", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onConnectionFailedRtmp(@NonNull final String reason) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (rtmpCamera1.reTry(5000, reason)) {
                    Toast.makeText(MainActivity.this, "Retry", Toast.LENGTH_SHORT)
                            .show();
                } else {
                    Toast.makeText(MainActivity.this, "Connection failed. " + reason, Toast.LENGTH_SHORT)
                            .show();
                    rtmpCamera1.stopStream();
                    pushBut.setText(R.string.start_button);
                }
            }
        });
    }

    @Override
    public void onNewBitrateRtmp(long bitrate) {

    }

    @Override
    public void onDisconnectRtmp() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(MainActivity.this, "Disconnected", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onAuthErrorRtmp() {

    }

    @Override
    public void onAuthSuccessRtmp() {

    }

    //拉流事件回调
    /**
     * 事件回调
     * @param nodePlayer 对象
     * @param event 事件状态码
     * @param msg   事件描述
     */
    @Override
    public void onEventCallback(NodePlayer nodePlayer, int event, String msg) {
        Log.i("NodeMedia.NodePlayer","onEventCallback:"+event+" msg:"+msg);

        switch (event) {
            case 1000:
                // 正在连接视频
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Connecting", Toast.LENGTH_SHORT).show();
                    }
                });
                break;
            case 1001:
                // 视频连接成功
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this, "Connection success", Toast.LENGTH_SHORT).show();
                    }
                });
                break;
            case 1002:
                // 视频连接失败 流地址不存在，或者本地网络无法和服务端通信，回调这里。5秒后重连， 可停止
//                nodePlayer.stopPlay();
                break;
            case 1003:
                // 视频开始重连,自动重连总开关
//                nodePlayer.stopPlay();
                break;
            case 1004:
                // 视频播放结束
                break;
            case 1005:
                // 网络异常,播放中断,播放中途网络异常，回调这里。1秒后重连，如不需要，可停止
//                nodePlayer.stopPlay();
                break;
            case 1006:
                //RTMP连接播放超时
                break;
            case 1100:
                // 播放缓冲区为空
//				System.out.println("NetStream.Buffer.Empty");
                break;
            case 1101:
                // 播放缓冲区正在缓冲数据,但还没达到设定的bufferTime时长
//				System.out.println("NetStream.Buffer.Buffering");
                break;
            case 1102:
                // 播放缓冲区达到bufferTime时长,开始播放.
                // 如果视频关键帧间隔比bufferTime长,并且服务端没有在缓冲区间内返回视频关键帧,会先开始播放音频.直到视频关键帧到来开始显示画面.
//				System.out.println("NetStream.Buffer.Full");
                break;
            case 1103:
//				System.out.println("Stream EOF");
                // 客户端明确收到服务端发送来的 StreamEOF 和 NetStream.Play.UnpublishNotify时回调这里
                // 注意:不是所有云cdn会发送该指令,使用前请先测试
                // 收到本事件，说明：此流的发布者明确停止了发布，或者因其网络异常，被服务端明确关闭了流
                // 本sdk仍然会继续在1秒后重连，如不需要，可停止
//                nodePlayer.stopPlay();
                break;
            case 1104:
                //解码后得到的视频高宽值 格式为:{width}x{height}
                break;
            default:
                break;
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        /**
         * 停止播放
         */
        np.stop();

        /**
         * 释放资源
         */
        np.release();
    }
    @Override
    public void surfaceCreated(SurfaceHolder holder) {

    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        if (rtmpCamera1.isStreaming()) {
            rtmpCamera1.stopStream();
            pushBut.setText(getResources().getString(R.string.start_button));
        }
        rtmpCamera1.stopPreview();
    }

}

